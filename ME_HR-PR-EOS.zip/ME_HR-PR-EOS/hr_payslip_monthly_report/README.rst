Payroll-Payslip Reporting v12
=============================

This Module help Human resource managers to get a over all view for the payslips as pivot


Features
========

* Pivot view for HR payslips.
* Group By options like Employee wise, department wise, job title wise, date wise, status wise and Company wise.
* Spot Export to XLS Report.


Depends
=======
[hr_payroll] addon Odoo


Tech
====
* [XML] - Odoo views


Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon


License
=======
GNU LGPL, Version 3 (LGPLv3)
(http://www.gnu.org/licenses/agpl.html)


Bug Tracker
===========

Contact odoo@cybrosys.com


Authors
-------
* Nikhil Krishnan <nikhil@cybrosys.in>
* Niyas Raphy <niyas@cybrosys.in>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.